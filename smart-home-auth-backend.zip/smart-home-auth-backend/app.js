const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const dotenv = require('dotenv');
dotenv.config();  // 这一行必须确保 .env 文件中的变量被加载

const app = express();
const PORT = process.env.PORT || 5000;

app.use(bodyParser.json());

// 创建 MySQL 连接池
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
});

// 测试数据库连接
db.getConnection((err) => {
    if (err) {
        console.error('连接 MySQL 数据库失败:', err);
    } else {
        console.log('成功连接到 MySQL 数据库');
    }
});

// 使用路由
app.use('/auth', authRoutes);

app.listen(PORT, () => {
    console.log(`服务器正在端口 ${PORT} 运行`);
});

module.exports = db;
