const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../app');  // 引入 MySQL 连接
const dotenv = require('dotenv');
dotenv.config();

// 注册新用户
router.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        // 查询是否已存在用户
        const [existingUser] = await db.promise().query(`SELECT * FROM users WHERE email = ?`, [email]);
        if (existingUser.length > 0) {
            return res.status(400).json({ message: '用户已存在' });
        }

        // 加密密码
        const hashedPassword = await bcrypt.hash(password, 10);

        // 插入新用户到 MySQL
        await db.promise().query(`INSERT INTO users (username, email, password) VALUES (?, ?, ?)`, [username, email, hashedPassword]);

        res.status(201).json({ message: '用户注册成功' });
    } catch (error) {
        res.status(500).json({ error: '服务器错误' });
    }
});

// 用户登录
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // 查询用户
        const [user] = await db.promise().query(`SELECT * FROM users WHERE email = ?`, [email]);
        if (user.length === 0) {
            return res.status(400).json({ message: '用户不存在' });
        }

        // 验证密码
        const isMatch = await bcrypt.compare(password, user[0].password);
        if (!isMatch) {
            return res.status(400).json({ message: '密码错误' });
        }

        // 生成 JWT 令牌
        const token = jwt.sign({ id: user[0].id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: '服务器错误' });
    }
});

module.exports = router;
